#include "camera.h"

Camera::Camera()
{

}

Camera::~Camera(){

}



