#ifndef COMPONENT_H
#define COMPONENT_H

#include<geometryengine.h>
#include"BasicIO.h"
class Component
{
public:
    virtual unsigned int getID();

    Component();



};


#endif // COMPONENT_H
